package FIXER.FIXER_BE.dto.User;

import lombok.Data;

@Data
public class CheckUserIdRequest {
    private String user_id;
}