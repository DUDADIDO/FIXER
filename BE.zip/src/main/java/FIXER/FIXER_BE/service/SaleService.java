package FIXER.FIXER_BE.service;

public class SaleService {
}
